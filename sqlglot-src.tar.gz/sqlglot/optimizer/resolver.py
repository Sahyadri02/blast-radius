from __future__ import annotations

import itertools
import typing as t

from sqlglot import exp
from sqlglot.dialects.dialect import Dialect
from sqlglot.errors import OptimizeError
from sqlglot.helper import seq_get, SingleValuedMapping
from sqlglot.optimizer.scope import Scope

if t.TYPE_CHECKING:
    from sqlglot.schema import Schema
    from collections.abc import Sequence, Mapping


class Resolver:
    """
    Helper for resolving columns.

    This is a class so we can lazily load some things and easily share them across functions.
    """

    def __init__(self, scope: Scope, schema: Schema) -> None:
        self.scope: Scope = scope
        self.schema: Schema = schema
        self.dialect: Dialect = schema.dialect or Dialect()
        self._source_columns: dict[str, Sequence[str]] | None = None
        self._source_nodes: dict[str, exp.Selectable] | None = None
        self._unambiguous_columns: Mapping[str, str] | None = None
        self._all_columns: set[str] | None = None
        self._get_source_columns_cache: dict[tuple[str, bool], Sequence[str]] = {}
        self._column_type_from_scope_cache: dict[tuple[int, str], exp.DataType | None] = {}
        self._outer_resolvers: list[Resolver] | None = None
        self._select_aliases: set[str] | None = None

    def get_table(
        self,
        column: exp.Column | exp.Identifier,
        source_columns: dict[str, Sequence[str]] | None = None,
    ) -> exp.Identifier | None:
        """
        Get the table for a column or struct root identifier.

        Args:
            column: A column or struct root identifier attached to the query AST, so its
                enclosing scope, joins, and aliases are available during resolution.
            source_columns: If provided, restrict the lookup to these source columns.
        Returns:
            The table name if it can be found/inferred.
        """
        column_name = column.name

        join_context = self._get_column_join_context(column) if source_columns is None else None
        is_semi_or_anti_join = join_context is not None and join_context.is_semi_or_anti_join

        # A SEMI/ANTI join's own table is excluded from the global lookup below, so skip it here
        table_name = (
            None
            if is_semi_or_anti_join
            else self._get_table_name_from_sources(column_name, source_columns)
        )

        if not table_name and join_context is not None:
            # Fall-back case: If we couldn't find the `table_name` from ALL of the sources,
            # attempt to disambiguate the column based on other characteristics e.g if this column is in a join condition,
            # we may be able to disambiguate based on the source order.
            try:
                table_name = self._get_table_name_from_sources(
                    column_name, self._get_available_source_columns(join_context)
                )
            except OptimizeError:
                pass

        if (
            not table_name
            and source_columns is None
            and column_name not in self.all_columns
            and column.find_ancestor(exp.Select) is self.scope.expression
            and not (
                self.dialect.TABLES_REFERENCEABLE_AS_COLUMNS
                and column_name in self.scope.selected_sources
            )
        ):
            # Skip back-projection for alias refs — _expand_alias_refs handles them.
            if column_name not in self.select_aliases or (
                isinstance(ancestor := column.find_ancestor(exp.Alias, exp.Select), exp.Alias)
                and ancestor.alias == column_name
            ):
                source_columns = (
                    self._get_available_source_columns(join_context)
                    if join_context is not None
                    else self._get_all_source_columns()
                )
                table_name = self._get_unknown_tvf_table(source_columns)

        if not table_name:
            return None

        if table_name not in self.scope.selected_sources:
            return exp.to_identifier(table_name)

        node: exp.Expr = self.scope.selected_sources[table_name][0]

        if isinstance(node, exp.Query):
            while node and node.alias != table_name and node.parent:
                node = node.parent

        node_alias = node.args.get("alias")
        if node_alias:
            return exp.to_identifier(node_alias.this)

        return exp.to_identifier(table_name)

    def outer_resolvers(self) -> list[Resolver]:
        """Resolvers for the outer scopes a correlated subquery can reference, innermost first."""
        if self._outer_resolvers is None:
            self._outer_resolvers = []
            scope = self.scope
            while scope.can_be_correlated and scope.parent:
                scope = scope.parent
                self._outer_resolvers.append(Resolver(scope, self.schema))
        return self._outer_resolvers

    def _get_unknown_tvf_table(self, source_columns: dict[str, Sequence[str]]) -> str | None:
        if not self.has_unknown_sources or self.scope.can_be_correlated:
            return None

        unknown_tvf_names = []
        for name, columns in source_columns.items():
            if columns and "*" not in columns:
                continue
            source = self.scope.sources.get(name)
            # Non-TVF tables are expected to have schemas supplied, so only functions can be unknown
            if isinstance(source, exp.Table) and isinstance(source.this, exp.Func):
                unknown_tvf_names.append(name)
            else:
                return None

        return unknown_tvf_names[0] if len(unknown_tvf_names) == 1 else None

    @property
    def has_unknown_sources(self) -> bool:
        """Whether some source's columns can't be determined, e.g. a table missing from the schema."""
        return any(
            not columns or "*" in columns for columns in self._get_all_source_columns().values()
        )

    @property
    def all_columns(self) -> set[str]:
        """All available columns of all sources in this scope"""
        if self._all_columns is None:
            self._all_columns = {
                column for columns in self._get_all_source_columns().values() for column in columns
            }
        return self._all_columns

    @property
    def select_aliases(self) -> set[str]:
        if self._select_aliases is None:
            expression = self.scope.expression
            self._select_aliases = (
                {s.alias for s in expression.selects if isinstance(s, exp.Alias)}
                if isinstance(expression, exp.Select)
                else set()
            )
        return self._select_aliases

    def get_source_columns_from_set_op(self, expression: exp.Expr) -> list[str]:
        if isinstance(expression, exp.Select):
            return expression.named_selects
        if isinstance(expression, exp.Subquery):
            return self.get_source_columns_from_set_op(expression.unnest())
        if not isinstance(expression, exp.SetOperation):
            raise OptimizeError(f"Unknown set operation: {expression}")

        set_op = expression

        # BigQuery specific set operations modifiers, e.g INNER UNION ALL BY NAME
        on_column_list = set_op.args.get("on")

        if on_column_list:
            # The resulting columns are the columns in the ON clause:
            # {INNER | LEFT | FULL} UNION ALL BY NAME ON (col1, col2, ...)
            columns = [col.name for col in on_column_list]
        elif set_op.side or set_op.kind:
            side = set_op.side
            kind = set_op.kind

            # Visit the children UNIONs (if any) in a post-order traversal
            left = self.get_source_columns_from_set_op(set_op.this)
            right = self.get_source_columns_from_set_op(set_op.expression)

            # We use dict.fromkeys to deduplicate keys and maintain insertion order
            if side == "LEFT":
                columns = left
            elif side == "FULL":
                columns = list(dict.fromkeys(left + right))
            elif kind == "INNER":
                columns = list(dict.fromkeys(left).keys() & dict.fromkeys(right).keys())
        else:
            columns = set_op.named_selects

        return columns

    def get_source_columns(self, name: str, only_visible: bool = False) -> Sequence[str]:
        """Resolve the source columns for a given source `name`."""
        cache_key = (name, only_visible)
        if cache_key not in self._get_source_columns_cache:
            if name not in self.scope.sources:
                raise OptimizeError(f"Unknown table: {name}")

            source = self.scope.sources[name]

            # A pivoted CTE reference is stored as an exp.Table in the scope sources (see
            # _traverse_tables in scope.py), but the underlying CTE Scope still holds the
            # column information we need to resolve pre-pivot columns.
            if (
                isinstance(source, exp.Table)
                and not source.db
                and source.args.get("pivots")
                and source.name in self.scope.cte_sources
            ):
                source = self.scope.cte_sources[source.name]

            if isinstance(source, exp.Table):
                columns = self.schema.column_names(source, only_visible)
            elif isinstance(source, Scope) and isinstance(
                source_expr := source.expression, (exp.Values, exp.Unnest, exp.Lateral)
            ):
                columns = source_expr.named_selects

                # in bigquery, unnest structs are automatically scoped as tables, so you can directly select
                # a struct field in a query. This handles the case where the unnest is statically defined.
                if self.dialect.UNNEST_COLUMN_ONLY and isinstance(source_expr, exp.Unnest):
                    if not source_expr.type or source_expr.type.is_type(exp.DType.UNKNOWN):
                        unnest_expr = seq_get(source_expr.expressions, 0)
                        if isinstance(unnest_expr, exp.Column) and self.scope.parent:
                            col_type = self._get_unnest_column_type(unnest_expr, self.scope.parent)
                            if col_type and col_type.is_type(exp.DType.ARRAY):
                                element_types = col_type.expressions
                                if element_types:
                                    source_expr.type = element_types[0].copy()
                            elif col_type:
                                source_expr.type = col_type.copy()
                        elif isinstance(unnest_expr, exp.Array):
                            first_elem = seq_get(unnest_expr.expressions, 0)
                            if isinstance(first_elem, exp.Struct) and all(
                                isinstance(f, exp.PropertyEQ) for f in first_elem.expressions
                            ):
                                columns.extend(f.name for f in first_elem.expressions)

                    columns.extend(self._struct_field_names(source_expr.type))
                elif isinstance(source_expr, exp.Lateral) and isinstance(
                    source_expr.this, exp.Explode
                ):
                    explode_col = source_expr.this.this

                    # If the column is unqualified at this point, it couldn't be resolved when
                    # this scope's children were qualified; disambiguating it here would require
                    # enumerating this very source's columns, i.e recurse without bound
                    if isinstance(explode_col, exp.Column) and explode_col.table and source.parent:
                        col_type = self._get_unnest_column_type(explode_col, source.parent)
                        columns.extend(self._struct_field_names(col_type))
                elif isinstance(source_expr, exp.Lateral) and isinstance(
                    source_expr.this, exp.Query
                ):
                    columns = source_expr.this.named_selects
            elif isinstance(source, Scope) and isinstance(source.expression, exp.SetOperation):
                columns = self.get_source_columns_from_set_op(source.expression)
            else:
                selectable = source.expression.assert_is(exp.Selectable)
                select = seq_get(selectable.selects, 0)

                if isinstance(select, exp.QueryTransform):
                    # https://spark.apache.org/docs/3.5.1/sql-ref-syntax-qry-select-transform.html
                    schema = select.args.get("schema")
                    columns = [c.name for c in schema.expressions] if schema else ["key", "value"]
                else:
                    columns = selectable.named_selects

            node, _ = self.scope.selected_sources.get(name) or (None, None)
            if node is None and name in self.scope.semi_or_anti_join_tables:
                # SEMI/ANTI sources are not selected, but their column alias lists still apply.
                if self._source_nodes is None:
                    self._source_nodes = dict(self.scope.references)
                node = self._source_nodes.get(name)

            if isinstance(node, Scope):
                column_aliases = node.expression.alias_column_names
            elif isinstance(node, exp.Expr):
                column_aliases = node.alias_column_names
            else:
                column_aliases = []

            if column_aliases:
                # If the source's columns are aliased, their aliases shadow the corresponding column names.
                # This can be expensive if there are lots of columns, so only do this if column_aliases exist.
                columns = [
                    alias or name
                    for (name, alias) in itertools.zip_longest(columns, column_aliases)
                ]

            self._get_source_columns_cache[cache_key] = columns

        return self._get_source_columns_cache[cache_key]

    def _get_all_source_columns(self) -> dict[str, Sequence[str]]:
        if self._source_columns is None:
            self._source_columns = {
                source_name: self.get_source_columns(source_name)
                for source_name, source in itertools.chain(
                    self.scope.selected_sources.items(), self.scope.lateral_sources.items()
                )
            }
        return self._source_columns

    def _get_table_name_from_sources(
        self, column_name: str, source_columns: dict[str, Sequence[str]] | None = None
    ) -> str | None:
        if source_columns is None:
            # If not supplied, get all sources to calculate unambiguous columns
            if self._unambiguous_columns is None:
                self._unambiguous_columns = self._get_unambiguous_columns(
                    self._get_all_source_columns()
                )

            unambiguous_columns = self._unambiguous_columns
        else:
            unambiguous_columns = self._get_unambiguous_columns(source_columns)

        return unambiguous_columns.get(column_name)

    def _get_column_join_context(self, column: exp.Column | exp.Identifier) -> exp.Join | None:
        """
        Check if a column participating in a join can be qualified based on the source order.
        """
        args = self.scope.expression.args
        joins = args.get("joins")

        if not joins or args.get("laterals") or args.get("pivots"):
            # Feature gap: We currently don't try to disambiguate columns if other sources
            # (e.g laterals, pivots) exist alongside joins
            return None

        join_ancestor = column.find_ancestor(exp.Join, exp.Select)

        if isinstance(join_ancestor, exp.Join):
            join_name = join_ancestor.alias_or_name
            if (
                join_name in self.scope.selected_sources
                or join_name in self.scope.semi_or_anti_join_tables
            ):
                # Ensure that the found ancestor is a join that contains an actual source,
                # e.g in Clickhouse `b` is an array expression in `a ARRAY JOIN b`
                return join_ancestor

        return None

    def _get_available_source_columns(
        self, join_ancestor: exp.Join, join_group: bool = False
    ) -> dict[str, Sequence[str]]:
        """
        Get the source columns that are available at the point where a column is referenced.

        For columns in JOIN conditions, this only includes tables that have been joined
        up to that point. Example:

        ```
        SELECT * FROM t_1 INNER JOIN ... INNER JOIN t_n ON t_1.a = c INNER JOIN t_n+1 ON ...
        ```                                                        ^
                                                                   |
                                +----------------------------------+
                                |
                                ⌄
        The unqualified column `c` is not ambiguous if no other sources up until that
        join i.e t_1, ..., t_n, contain a column named `c`.

        With join_group=True, use the enclosing join group and treat comma joins as boundaries.

        """
        expression = join_ancestor.parent if join_group else self.scope.expression
        assert expression is not None
        args = expression.args

        # Collect the sources visible up to the current join.
        from_ = args.get("from_")
        sources = [from_.this if from_ else expression]

        for join in args["joins"][: t.cast(int, join_ancestor.index) + 1]:
            if join_group and not (
                join.args.get("on")
                or join.args.get("using")
                or join.method
                or join.side
                or join.kind
            ):
                sources.clear()

            # An earlier SEMI/ANTI join's table is only visible within its own ON clause
            if join is join_ancestor or not join.is_semi_or_anti_join:
                sources.append(join.this)

        available_sources = {}
        while sources:
            source = sources.pop()
            if name := source.alias_or_name:
                available_sources[name] = self.get_source_columns(name)
            elif isinstance(source, exp.Subquery):
                sources.append(source.this)
                sources.extend(
                    join.this
                    for join in source.this.args.get("joins") or []
                    if not join.is_semi_or_anti_join
                )

        return available_sources

    def _get_unambiguous_columns(
        self, source_columns: dict[str, Sequence[str]]
    ) -> Mapping[str, str]:
        """
        Find all the unambiguous columns in sources.

        Args:
            source_columns: Mapping of names to source columns.

        Returns:
            Mapping of column name to source name.
        """
        if not source_columns:
            return {}

        source_columns_pairs = list(source_columns.items())

        first_table, first_columns = source_columns_pairs[0]

        if len(source_columns_pairs) == 1:
            # Performance optimization - avoid copying first_columns if there is only one table.
            return SingleValuedMapping(first_columns, first_table)

        # For BigQuery UNNEST_COLUMN_ONLY, build a mapping of original UNNEST aliases
        # from alias.columns[0] to their source names. This is used to resolve shadowing
        # where an UNNEST alias shadows a column name from another table.
        unnest_original_aliases: dict[str, str] = {}
        if self.dialect.UNNEST_COLUMN_ONLY:
            unnest_original_aliases = {
                alias_arg.columns[0].name: source_name
                for source_name, source in self.scope.sources.items()
                if (
                    isinstance(source.expression, exp.Unnest)
                    and (alias_arg := source.expression.args.get("alias"))
                    and alias_arg.columns
                )
            }

        unambiguous_columns = {col: first_table for col in first_columns}
        all_columns = set(unambiguous_columns)

        for table, columns in source_columns_pairs[1:]:
            unique = set(columns)
            ambiguous = all_columns.intersection(unique)
            all_columns.update(columns)

            for column in ambiguous:
                if column in unnest_original_aliases:
                    unambiguous_columns[column] = unnest_original_aliases[column]
                    continue

                unambiguous_columns.pop(column, None)
            for column in unique.difference(ambiguous):
                unambiguous_columns[column] = table

        return unambiguous_columns

    def _struct_field_names(self, col_type: exp.DataType | None) -> list[str]:
        if col_type and col_type.is_type(exp.DType.ARRAY):
            col_type = seq_get(col_type.expressions, 0)

        return (
            [k.name for k in col_type.expressions]
            if col_type and col_type.is_type(exp.DType.STRUCT)
            else []
        )

    def _get_unnest_column_type(self, column: exp.Column, scope: Scope) -> exp.DataType | None:
        """
        Get the type of a column being unnested/exploded from its source scope or table.

        Args:
            column: The column expression being unnested/exploded.
            scope: The scope to resolve the column in.

        Returns:
            The DataType of the column, or None if not found.
        """
        # if column is qualified, use that table, otherwise disambiguate using the resolver
        if column.table:
            table_name = column.table
        else:
            # use the parent scope's resolver to disambiguate the column
            parent_resolver = Resolver(scope, self.schema)
            table_identifier = parent_resolver.get_table(column)
            if not table_identifier:
                return None
            table_name = table_identifier.name

        source = scope.sources.get(table_name)
        return self._get_column_type_from_scope(source, column) if source else None

    def _get_column_type_from_scope(
        self, source: Scope | exp.Table, column: exp.Column
    ) -> exp.DataType | None:
        """
        Get a column's type from annotated projections or underlying table schemas.

        Args:
            source: The scope or table to search.
            column: The column to find the type for.

        Returns:
            The DataType of the column, or None if not found.
        """
        # A single source can be reachable through many paths of a scope DAG (e.g. a CTE
        # referenced by several other CTEs). The schema and scope are immutable during
        # qualification, so the type of `column` under `source` depends only on
        # `(source, column name)`; memoize it to walk each source once.
        cache_key = (id(source), column.name)
        if cache_key in self._column_type_from_scope_cache:
            return self._column_type_from_scope_cache[cache_key]

        # None is a valid result if DataType could not be determined!
        result: exp.DataType | None = None
        if isinstance(source, exp.Table):
            # base table - get the column type from schema
            col_type = self.schema.get_column_type(source, column)
            if col_type and not col_type.is_type(exp.DType.UNKNOWN):
                result = col_type
        elif isinstance(source, Scope):
            if isinstance(source.expression, exp.Select):
                for projection in source.expression.selects:
                    if projection.alias_or_name == column.name:
                        if projection.type and not projection.type.is_type(exp.DType.UNKNOWN):
                            result = projection.type
                        break

            if result is None:
                for nested_source in source.sources.values():
                    nested_type = self._get_column_type_from_scope(nested_source, column)
                    if nested_type and not nested_type.is_type(exp.DType.UNKNOWN):
                        result = nested_type
                        break

        self._column_type_from_scope_cache[cache_key] = result
        return result
