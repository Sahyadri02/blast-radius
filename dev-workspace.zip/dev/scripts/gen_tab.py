import ast,random,subprocess,os,sys
random.seed(int(sys.argv[1])); N=int(sys.argv[2]); out=sys.argv[3]
os.chdir('/home/claude/wt')
files=['sqlglot/parser.py','sqlglot/generator.py','sqlglot/tokens.py','sqlglot/expressions/core.py']
import glob
if len(sys.argv)<5: files+=glob.glob('sqlglot/parsers/*.py')+glob.glob('sqlglot/generators/*.py')+glob.glob('sqlglot/dialects/*.py')
cands=[]
for f in files:
    src=open(f).read(); tree=ast.parse(src); lines=src.split('\n')
    for cls in ast.walk(tree):
        if not isinstance(cls,ast.ClassDef): continue
        for st in cls.body:
            if isinstance(st,(ast.Assign,ast.AnnAssign)) and isinstance(st.value,ast.Dict):
                d=st.value
                ents=[(k,v) for k,v in zip(d.keys,d.values) if k is not None and k.lineno==k.end_lineno==v.lineno==v.end_lineno]
                if len(ents)<3: continue
                for k,v in ents: cands.append((f,d,ents,k,v))
random.shuffle(cands)
made=0; used=set()
for f,d,ents,k,v in cands:
    if made>=N: break
    src=open(f).read(); lines=src.split('\n')
    line=lines[v.lineno-1]; seg=line[v.col_offset:v.end_col_offset]
    kind=random.random()
    if isinstance(v,ast.Constant) and isinstance(v.value,str) and v.value:
        new=repr(v.value[:-1] if len(v.value)>1 else v.value+'X')
    elif isinstance(v,ast.Constant) and isinstance(v.value,bool):
        new=repr(not v.value)
    else:
        others=[o for kk,o in ents if o is not v]
        o=random.choice(others); ol=lines[o.lineno-1]; new=ol[o.col_offset:o.end_col_offset]
        if new==seg: continue
    nl=line[:v.col_offset]+new+line[v.end_col_offset:]
    if (f,v.lineno) in used: continue
    used.add((f,v.lineno))
    lines[v.lineno-1]=nl; open(f,'w').write('\n'.join(lines))
    name=f"t{sys.argv[1]}_{made:02d}"
    p=subprocess.run(['git','diff'],capture_output=True,text=True).stdout
    subprocess.run(['git','checkout','-q','--','.'])
    try: compile('\n'.join(lines),f,'exec')
    except SyntaxError: continue
    open(f'{out}/{name}.patch','w').write(p); made+=1
    print(name,f,v.lineno,seg[:40],'->',new[:40])
