import json,sys,os,glob,time,resource
sys.path.insert(0,'/home/claude/entry')
import selector as S, trun
SRC='/home/claude/sqlglot'
def load(tj): 
    t=json.load(open(tj))['tests']; return t,{x['id']:x['number'] for x in t}
POOL=None
def check(name, commits, truth_fn, sel_fn, tests, slow=1.0):
    tot=time.time(); r0=resource.getrusage(resource.RUSAGE_CHILDREN)
    bad=0
    for cid,ptxt in commits:
        truth=truth_fn(cid)
        cand=set(sel_fn(cid))|truth
        ids=[tests[i]['id'] for i in sorted(cand) if tests[i]['seconds']<slow]
        files=trun.patched_files(ptxt,SRC,S.parse_patch,S.apply)
        got=POOL.run_many([(0,SRC,files,ids,120)])[0] if files is not None else None
        if got is None: print(cid,'RUN BROKE',files is None); bad+=1; continue
        gotn={tests_id[x] for x in got}
        tr={i for i in truth if tests[i]['seconds']<slow}
        miss=tr-gotn; extra=gotn-truth
        if miss or extra: bad+=1
        print(cid[:12],'cand',len(ids),'truthfail',len(tr),'got',len(gotn),'MISS' if miss else '', [tests[i]['id'] for i in miss][:3],'EXTRA' if extra else '',[tests[i]['id'] for i in extra][:3])
    r=resource.getrusage(resource.RUSAGE_CHILDREN)
    print(name,'bad',bad,'wall',round(time.time()-tot,1),'cpu',round(r.ru_utime+r.ru_stime-r0.ru_utime-r0.ru_stime,1))
if __name__=='__main__':
    which=sys.argv[1]; POOL=trun.Pool(1)
    tests,tests_id=load('/home/claude/br/sample/tests.json')
    if which=='sample':
        A=json.load(open('/home/claude/br/sample/answers.json'))['commits']
        out=[json.loads(l) for l in open('/home/claude/samp_out.jsonl')]
        sel={d['commit']:[x for w in d['workers'] for x in w] for d in out}
        commits=[(c,open(f'/home/claude/br/sample/commits/{c}.patch').read()) for c in A]
        check('sample',commits,lambda c:set(A[c]['failing']),lambda c:sel.get(c,[]),tests)
    else:
        D=f'/home/claude/mut/{which}'
        out=[json.loads(l) for l in open(f'{D}/sel_out.jsonl')]
        sel={d['commit']:[x for w in d['workers'] for x in w] for d in out}
        cs=[os.path.basename(f)[:-4] for f in glob.glob(D+'/truth/*.txt')]
        commits=[(c,open(f'{D}/commits/{c}.patch').read()) for c in cs]
        def tf(c): return {tests_id[x.strip()] for x in open(f'{D}/truth/{c}.txt') if x.strip() in tests_id}
        check(which,commits,tf,lambda c:sel.get(c,[]),tests)
