import json,subprocess,os,sys
D='/home/claude/br/sample'
t=json.load(open(D+'/tests.json'))['tests']; ms=[round(x['seconds']*1000) for x in t]
A=json.load(open(D+'/answers.json'))['commits']
out=subprocess.run([os.environ.get('PY','python3'),sys.argv[1] if len(sys.argv)>1 else '/home/claude/entry/selector.py'],env=dict(os.environ,BR_DATA=D,BR_SRC='/home/claude/sqlglot'),capture_output=True,text=True).stdout
def cost(ws): 
    ws=[w for w in ws if w]
    return (max(sum(ms[i] for i in w) for w in ws)+2000*len(ws))/1000 if ws else 0
def orc(f):
    if not f: return 0
    best=1e9
    for k in range(1,9):
        L=[0]*k
        for i in sorted(f,key=lambda i:-ms[i]): L[L.index(min(L))]+=ms[i]
        best=min(best,(max(L)+2000*k)/1000)
    return best
T=O=0
for l in out.splitlines():
    d=json.loads(l); a=A[d['commit']]; s=set(x for w in d['workers'] for x in w)
    c=cost(d['workers']); o=orc(a['failing']); miss=bool(set(a['failing'])-s)
    T+=c+300*miss; O+=o
    print(f"{d['commit'][:10]} {a['kind']:8} fail={len(a['failing']):4} sel={len(s):5} cost={c:6.2f} oracle={o:5.2f} {'MISS' if miss else ''}")
print('total',round(T,1),'oracle',round(O,1))
