import json,glob,os,sys
sys.path.insert(0,'/home/claude/entry')
from selector import split,cost
T=json.load(open('br/sample/tests.json'))['tests']; ms=[round(x['seconds']*1000) for x in T]; idn={x['id']:x['number'] for x in T}
M=json.load(open('entry/cpumodel.json'))
SP=0.6
def est(run):
    ids=[T[i]['id'] for i in run]; cls={i.rsplit('::',1)[0] for i in ids}
    ex=[M['extra'].get(i,0) for i in ids]; npool=sum(1 for e in ex if e>0)
    return 0.03+sum(M['base'].get(c,0.3) for c in cls)+sum(M['self'].get(i,T[idn[i]]['seconds']) for i in ids)+sum(ex)-SP*max(0,npool-1)
def evalset(sel,truth,margin,fixture_skip,files_of):
    base=new=0;nrun=0
    for c,nums in sel.items():
        C=cost(split(nums,ms),ms)/1000; base+=C
        run=[i for i in nums if ms[i]<=3000]; keep=[i for i in nums if ms[i]>3000]
        if not run: new+=C; continue
        E=est(run); g=C-cost(split(keep,ms),ms)/1000-E
        if g<margin or (fixture_skip and any(p.startswith('tests/') for p in files_of(c))): new+=C; continue
        f=set(truth[c])&set(run); nrun+=1
        new+=min(C,cost(split(sorted(set(keep)|f),ms),ms)/1000)+E
    return round(base,1),round(new,1),nrun
import re
def files(p): return re.findall(r'^diff --git a/(\S+)',open(p).read(),re.M)
sets=[]
A=json.load(open('br/sample/answers.json'))['commits']
out=[json.loads(l) for l in open('samp_out.jsonl')]
sets.append(('sample',{d['commit']:[x for w in d['workers'] for x in w] for d in out},{c:A[c]['failing'] for c in A},lambda c:files(f'br/sample/commits/{c}.patch')))
for s in 'set1 set2 ds codex codex2 codex3 codex4 iseq fpm'.split():
    D=f'mut/{s}'; out=[json.loads(l) for l in open(f'{D}/sel_out2.jsonl')]
    tr={os.path.basename(f)[:-4]:[idn[x.strip()] for x in open(f) if x.strip() in idn] for f in glob.glob(D+'/truth/*.txt')}
    sets.append((s,{d['commit']:[x for w in d['workers'] for x in w] for d in out},tr,lambda c,D=D:files(f'{D}/commits/{c}.patch')))
for margin in (0.0,0.5,1.0):
  for fs in (False,True):
    tb=tn=0
    for name,sel,tr,fo in sets:
        b,n,k=evalset(sel,tr,margin,fs,fo); tb+=b; tn+=n
    print('margin',margin,'fixskip',fs,'base',round(tb,1),'new',round(tn,1))
for name,sel,tr,fo in sets: print(name,evalset(sel,tr,0.5,True,fo))
