import resource,subprocess,sys,time
t=time.time();p=subprocess.run(sys.argv[1:]);r=resource.getrusage(resource.RUSAGE_CHILDREN)
print('CPU',round(r.ru_utime+r.ru_stime,2),'wall',round(time.time()-t,1),file=sys.stderr)
