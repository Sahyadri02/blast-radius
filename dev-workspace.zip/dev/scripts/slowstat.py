import json,glob,os,sys
sys.path.insert(0,'/home/claude/entry')
from selector import split,cost
T=json.load(open('br/sample/tests.json'))['tests']; ms=[round(x['seconds']*1000) for x in T]; idn={x['id']:x['number'] for x in T}
slow=[i for i in range(len(T)) if ms[i]>3000]
import collections
selc=collections.Counter(); failc=collections.Counter(); ex_slow=0; ex_tot=0; allc=0
def orc(f): return cost(split(sorted(f),ms),ms)/1000
def go(sel,tr):
    global ex_slow,ex_tot,allc
    for c,nums in sel.items():
        if len(nums)>1500: allc+=1; continue
        f=set(tr.get(c,[])); C=cost(split(nums,ms),ms)/1000; O=orc(f)
        ex_tot+=C-O

        ns=set(nums)
        for s in slow:
            if s in ns: selc[s]+=1
            if s in f: failc[s]+=1
        nos=[i for i in nums if i not in slow or i in f]
        ex_slow+=C-cost(split(nos,ms),ms)/1000
A=json.load(open('br/sample/answers.json'))['commits']
out=[json.loads(l) for l in open('samp_out.jsonl')]
go({d['commit']:[x for w in d['workers'] for x in w] for d in out},{c:A[c]['failing'] for c in A})
for s in 'set1 set2 ds codex codex2 codex3 codex4 iseq fpm'.split():
    D=f'mut/{s}'; out=[json.loads(l) for l in open(f'{D}/sel_out2.jsonl')]
    tr={os.path.basename(f)[:-4]:[idn[x.strip()] for x in open(f) if x.strip() in idn] for f in glob.glob(D+'/truth/*.txt')}
    go({d['commit']:[x for w in d['workers'] for x in w] for d in out},tr)
for s in slow: print(T[s]['id'],ms[s],'selected',selc[s],'failed',failc[s])
print('excess total',round(ex_tot,1),'excess due to non-failing slow tests',round(ex_slow,1),'ALL selections',allc)
