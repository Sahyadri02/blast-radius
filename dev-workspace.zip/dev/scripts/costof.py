import json,sys,os,glob,subprocess
sys.path.insert(0,'/home/claude/entry'); from selector import cost
S=os.path.abspath(sys.argv[1]); R=S+'/run'
os.makedirs(R+'/commits',exist_ok=True)
for f in glob.glob(R+'/commits/*'): os.remove(f)
for p in glob.glob(S+'/commits/*.patch'): os.symlink(p,R+'/commits/'+os.path.basename(p))
subprocess.run(['cp','/home/claude/br/sample/tests.json',R+'/'])
sel=sys.argv[2] if len(sys.argv)>2 else '/home/claude/entry/selector.py'
out=subprocess.run(['python3',sel],env=dict(os.environ,BR_DATA=R,BR_SRC='/home/claude/sqlglot',BR_RUN='0'),capture_output=True,text=True).stdout
T=json.load(open('/home/claude/br/sample/tests.json'))['tests']; ms=[round(x['seconds']*1000) for x in T]
tot=0
for l in out.splitlines():
    d=json.loads(l); c=cost(d['workers'],ms)/1000; tot+=c; print(d['commit'], sum(len(w) for w in d['workers']), c)
print('total',round(tot,1))
