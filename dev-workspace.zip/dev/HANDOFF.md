# Blast Radius — work in progress (handoff from Claude chat session, Sat Nov 21 ~7:50 PM ET)

## What is live
- Repo root (Dockerfile, selector.py, fp.py, map.json.gz, sqlglot-src.tar.gz) = commit 5444fb2.
  Scored **202.4 s** (190.45 simulated + ~12 s CPU), **0 misses**. It is our locked-in final entry.
- Do NOT replace the root files until a new version passes every test set below with 0 misses.

## New version in this folder (dev/entry) — NOT yet submitted, NOT fully validated
Two new rules in `selector.py`:
1. **Lambda rule narrowed**: when only a lambda body changes, select tests covering the lambda's own
   lines (not the whole enclosing statement, e.g. all of Generator.TRANSFORMS), unless a lambda line
   ran during warm-up/collection (then old behaviour).
2. **Table rule** (big win): for import-time changes, run `fp.py --detail` on the patched tree
   (overlay of symlinks, see `_overlay`, `table_diff`, `table_mask`). It lists exactly which
   dict-table entries changed (e.g. `Parser.FUNCTIONS['LOG']` in Parser + every dialect copy).
   If ONLY entries of tracked dicts changed, select the tests that read those keys at test time
   (map keys `tacc`, `tphase`, `talias`, `tleaky`, `tderived` in map.json.gz, recorded by
   `mapgen/mapplugin.py` with `brtrack.TDict`). Falls back to the old rules when anything else
   changed, a table is "leaky", or the key was read during warm-up/outside tests.
   Generator dispatch tables (built from TRANSFORMS) are tracked as `dispatch:<class>`.

Results (simulated s, all 0 misses): sample 121.6 -> 108.3; set1 118 -> 92; set2 100 -> 65;
ds 186 -> 150; codex4 286 -> 256; iseq 30 -> 2.4; fpm 300 -> 254; dictm (8 core-table mutants) 250 -> 72.
`mut/tabm` = 50 random table-entry mutants (gen_tab.py); truth was still being computed — RUN IT
(`mut/truth.sh`) and check 0 misses before submitting.

## To ship the new version (Dockerfile changes needed)
- COPY selector.py map.json.gz fp.py brtrack.py to /app
- Build base table fingerprint: `RUN PYTHONHASHSEED=0 python -B /app/fp.py --detail /opt/sqlglot > /app/fp_detail.json`
  (fp_base.json is no longer used)
- Precompile sqlglot so the symlink overlay imports fast: `RUN python -m compileall -q /opt/sqlglot/sqlglot`
- Test as user nobody with read-only /opt and /app and small /tmp (64 MB) before submitting.

## Shelved idea (runner.py, trun.py, classcost.json, cpumodel.json)
Running selected tests inside the container and dropping passing ones. Fidelity was perfect on the
sample (needs pytz/duckdb/pandas/numpy in the image), but net gain was ~0-3 s because CPU is charged
1:1 and the optimizer tests spawn process pools. Not worth the risk now.

## Environment setup used
- sqlglot clone at pinned commit eb11aec4be8cb2122afe713a4816662c3f0fb2fa at /home/claude/sqlglot,
  a second worktree /home/claude/wt for truth runs, venv /home/claude/venv with
  pytest pytest-xdist pytest-timeout coverage duckdb pandas numpy pytz python-dateutil.
- Scripts assume paths under /home/claude (entry/, mapgen/, mut/, br/sample = the organizers' sample kit).
- `mut/eval.py <set>` = selector vs truth; `scripts/samp.py` = sample score; `scripts/costof.py <set>` = cost without truth.
- Mapping: `mapgen/runmap.sh` then `buildmap.py tests.json`; only the t* keys were merged into the old map.json.gz.
