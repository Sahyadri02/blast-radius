"""Test-running server for the selector.

Started once as `python -B -s runner.py`. It loads the heavy third-party
libraries the sqlglot tests use, then reads one JSON job per stdin line:
    {"tag": ..., "root": <patched tree>, "ids": [test ids], "timeout": s}
For each job it forks a child that imports sqlglot and the tests from `root`
(a fresh import of the patched code), runs the tests with unittest, and
reports {"tag": ..., "fail": [ids]} (or {"tag": ..., "error": "..."}) on stdout.
Any test that cannot be loaded, errors, fails, has a failing subtest, passes
unexpectedly, or whose class/module fixture errors counts as failing.
"""
import json
import os
import sys

for _m in ("unittest", "numpy", "pandas", "duckdb", "pytz", "dateutil", "dateutil.parser",
           "decimal", "datetime", "zoneinfo", "tracemalloc", "concurrent.futures",
           "multiprocessing", "pickle", "tempfile"):
    try:
        __import__(_m)
    except BaseException:
        pass

import gc
gc.collect()
gc.freeze()


def child(job, wfd):
    import signal
    signal.alarm(int(job.get("timeout", 60)))
    devnull = os.open(os.devnull, os.O_WRONLY)
    os.dup2(devnull, 1)
    os.dup2(devnull, 2)
    root = job["root"]
    ids = job["ids"]
    os.chdir(root)
    sys.path.insert(0, root)
    import importlib
    import unittest

    import resource
    prof = {} if job.get("profile") else None
    fail = set()
    by_class = {}
    by_module = {}
    suite = unittest.TestSuite()
    for tid in ids:
        f, c, m = tid.split("::")
        modname = f[:-3].replace("/", ".")
        by_class.setdefault(modname + "." + c, []).append(tid)
        by_module.setdefault(modname, []).append(tid)
        try:
            mod = importlib.import_module(modname)
            if not os.path.realpath(mod.__file__).startswith(os.path.realpath(root)) and \
                    not os.path.abspath(mod.__file__).startswith(root):
                raise ImportError("test module not from the patched tree")
            cls = getattr(mod, c)
            t = cls(m)
            t._br_id = tid
            suite.addTest(t)
        except BaseException:
            fail.add(tid)
    try:
        import sqlglot
        if not os.path.abspath(sqlglot.__file__).startswith(root):
            fail.update(ids)  # wrong sqlglot: trust nothing
    except BaseException:
        fail.update(ids)

    class R(unittest.TestResult):
        def _mark(self, test):
            tid = getattr(test, "_br_id", None)
            if tid is not None:
                fail.add(tid)
                return
            # _ErrorHolder for setUpClass / tearDownClass / setUpModule errors
            d = str(getattr(test, "description", test))
            hit = False
            for key, lst in by_class.items():
                if key in d:
                    fail.update(lst); hit = True
            if not hit:
                for key, lst in by_module.items():
                    if key in d:
                        fail.update(lst); hit = True
            if not hit:
                fail.update(ids)

        def startTest(self, test):
            if prof is not None:
                ru = resource.getrusage(resource.RUSAGE_SELF)
                self._t0 = ru.ru_utime + ru.ru_stime

        def stopTest(self, test):
            if prof is not None:
                ru = resource.getrusage(resource.RUSAGE_SELF)
                prof[getattr(test, "_br_id", "?")] = ru.ru_utime + ru.ru_stime - self._t0

        def addError(self, test, err):
            self._mark(test)

        def addFailure(self, test, err):
            self._mark(test)

        def addSubTest(self, test, subtest, err):
            if err is not None:
                self._mark(test)

        def addUnexpectedSuccess(self, test):
            self._mark(test)

    try:
        suite.run(R())
    except BaseException:
        fail.update(ids)
    try:
        import concurrent.futures.process as _cfp  # let process pools finish so their CPU is counted
    except Exception:
        pass
    ru = resource.getrusage(resource.RUSAGE_SELF)
    rc = resource.getrusage(resource.RUSAGE_CHILDREN)
    os.write(wfd, json.dumps({"fail": sorted(fail), "cpu": ru.ru_utime + ru.ru_stime + rc.ru_utime + rc.ru_stime,
                              "prof": prof}).encode())
    os._exit(0)


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        job = json.loads(line)
        r, w = os.pipe()
        pid = os.fork()
        if pid == 0:
            os.close(r)
            try:
                child(job, w)
            finally:
                os._exit(1)
        os.close(w)
        chunks = []
        while True:
            b = os.read(r, 1 << 16)
            if not b:
                break
            chunks.append(b)
        os.close(r)
        _, status = os.waitpid(pid, 0)
        res = {"tag": job.get("tag")}
        try:
            if status != 0:
                raise ValueError("child status %d" % status)
            d = json.loads(b"".join(chunks))
            res["fail"] = d["fail"]
            res["cpu"] = d.get("cpu")
            res["prof"] = d.get("prof")
        except Exception as e:
            res["error"] = repr(e)
        out.write(json.dumps(res) + "\n")
        out.flush()


if __name__ == "__main__":
    main()
