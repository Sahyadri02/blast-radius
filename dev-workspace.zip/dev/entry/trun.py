"""Build a patched view of the sqlglot tree and run tests against it."""
import json
import os
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))


_TREE = {}


def _tree(src):
    """All dirs and files under src (relative), cached."""
    if src not in _TREE:
        dirs, files = [], []
        for d, ds, fs in os.walk(src):
            ds[:] = [x for x in ds if x != ".git"]
            rel = os.path.relpath(d, src)
            rel = "" if rel == "." else rel
            dirs.append(rel)
            for f in fs:
                files.append(rel + "/" + f if rel else f)
        _TREE[src] = (dirs, files)
    return _TREE[src]


def build_overlay(src, files, base=None):
    """files: {relpath: text or None (deleted)}. Returns a patched view of src:
    real directories, unchanged files as symlinks (test sources as copies with
    their timestamps, so a test's resolved __file__ stays inside the view),
    changed files written out."""
    root = tempfile.mkdtemp(prefix="ov_", dir=base)
    dirs, all_files = _tree(src)
    for d in dirs:
        if d:
            os.makedirs(os.path.join(root, d), exist_ok=True)
    for f in all_files:
        if f in files:
            continue
        s_ = os.path.join(src, f)
        if f.startswith("tests/") and f.endswith(".py"):
            shutil.copy2(s_, os.path.join(root, f))
        else:
            os.symlink(s_, os.path.join(root, f))
    for f, text in files.items():
        if text is None:
            continue
        os.makedirs(os.path.dirname(os.path.join(root, f)) or root, exist_ok=True)
        with open(os.path.join(root, f), "w", encoding="utf-8", newline="") as fh:
            fh.write(text)
    return root


def _ccpu(pid):
    try:
        f = open("/proc/%d/stat" % pid).read().split(")")[1].split()
        return sum(int(x) for x in f[13:15]) / 100
    except Exception:
        return 0.0


class Pool:
    """A few long-lived runner.py servers; jobs go to whichever is free."""

    def __init__(self, n=2, python=None):
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONHASHSEED="0")
        env.pop("PYTHONPATH", None)
        self.procs = []
        self.profile = False
        for _ in range(n):
            self.procs.append(subprocess.Popen(
                [python or sys.executable, "-B", "-s", os.path.join(HERE, "runner.py")],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                text=True, env=env, cwd="/"))

    def run_many(self, jobs, deadline=None):
        """jobs: list of (tag, src, files, ids, timeout). Returns {tag: set of failing ids or None}."""
        import threading, queue, time
        q = queue.Queue()
        for j in jobs:
            q.put(j)
        res = {}
        self.cpu = {}
        self.prof = {}

        def work(p):
            while True:
                try:
                    tag, src, files, ids, timeout = q.get_nowait()[:5]
                except queue.Empty:
                    return
                if deadline is not None and time.time() + timeout > deadline:
                    res[tag] = None
                    continue
                root = None
                try:
                    root = build_overlay(src, files)
                    p.stdin.write(json.dumps({"tag": tag, "root": root, "ids": ids, "timeout": timeout, "profile": self.profile}) + "\n")
                    p.stdin.flush()
                    c0 = _ccpu(p.pid)
                    line = p.stdout.readline()
                    if os.environ.get("BR_DEBUG"):
                        time.sleep(0.05)
                        sys.stderr.write("job %s actual %.2f\n" % (tag, _ccpu(p.pid) - c0))
                    d = json.loads(line)
                    res[tag] = set(d["fail"]) if "fail" in d else None
                    self.cpu[tag] = d.get("cpu")
                    self.prof[tag] = d.get("prof")
                except Exception:
                    res[tag] = None
                finally:
                    if root:
                        shutil.rmtree(root, ignore_errors=True)

        ts = [threading.Thread(target=work, args=(p,)) for p in self.procs]
        for t in ts:
            t.start()
        for t in ts:
            t.join()
        return res

    def close(self):
        if os.environ.get("BR_DEBUG"):
            for p in self.procs:
                try:
                    f = open("/proc/%d/stat" % p.pid).read().split(")")[1].split()
                    sys.stderr.write("zygote cpu %s\n" % [int(x) / 100 for x in f[11:15]])
                except Exception:
                    pass
        for p in self.procs:
            try:
                p.stdin.close(); p.wait(timeout=5)
            except Exception:
                p.kill()


def run_tests(src, files, ids, timeout=60, python=None):
    if not ids:
        return set()
    pool = Pool(1, python)
    try:
        return pool.run_many([(0, src, files, ids, timeout)])[0]
    finally:
        pool.close()


def patched_files(text, src, parse_patch, apply):
    """{relpath: new text or None}, or None if the patch can't be applied faithfully."""
    files = {}
    for path, f in parse_patch(text).items():
        if f.get("binary"):
            return None
        old, new = f["old"], f["new"]
        if old is not None:
            try:
                with open(os.path.join(src, old), encoding="utf-8", newline="") as fh:
                    ot = fh.read()
            except Exception:
                return None
        else:
            ot = ""
        if new is None:
            files[old] = None
            continue
        nt = apply(ot, f["hunks"]) if f["hunks"] else ot
        if old is not None and old != new:
            files[old] = None
        files[new] = nt
    return files
