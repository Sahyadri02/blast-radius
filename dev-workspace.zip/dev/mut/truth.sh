#!/bin/bash
# usage: truth.sh OUTDIR  -> writes OUTDIR/truth/<id>.txt with failing node ids
. /home/claude/venv/bin/activate
cd /home/claude/wt; export SKIP_INTEGRATION=0 PYTHONPATH=/home/claude/wt
mkdir -p $1/truth
for p in $1/commits/*.patch; do
  id=$(basename $p .patch); [ -f $1/truth/$id.txt ] && continue
  git apply $p || { echo "apply fail $id"; continue; }
  timeout 900 python -m pytest -q -p no:cacheprovider -n 2 -rfE --timeout 300 tests > $1/truth/$id.log 2>&1
  sed -n '/short test summary info/,$p' $1/truth/$id.log | grep -E "^(FAILED|ERROR|SUBFAILED)" | grep -oE "tests/[^ ]+\.py::[A-Za-z0-9_:]+" | sort -u > $1/truth/$id.txt
  git checkout -q -- . ; git clean -qfd tests sqlglot
  echo "$id $(wc -l < $1/truth/$id.txt) $(tail -n1 $1/truth/$id.log)"
done
