#!/bin/bash
cd /home/claude/sqlglot
for i in 0 1 2 3; do
  SKIP_INTEGRATION=0 MAP_OUT=/home/claude/mapgen/out$i PYTHONPATH=/home/claude/mapgen /home/claude/venv/bin/python -m pytest -q -p no:cacheprovider -p mapplugin $(cat /home/claude/mapgen/shard$i.txt) > /home/claude/mapgen/log$i.txt 2>&1 &
done
wait
echo done
