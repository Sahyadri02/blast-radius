import json, os, sys, coverage
ROOT="/home/claude/sqlglot"
tests=json.load(open(sys.argv[1]))['tests']
num={t['id']:t['number'] for t in tests}
def resolve(c):
    """Context -> test mask (class-level setup contexts cover every test of the class)."""
    if c in num: return 1<<num[c]
    if c.startswith("COLLECT::"):
        f=c[9:]; m=0
        for k,n in num.items():
            if k.split("::")[0]==f: m|=1<<n
        return m or None
    if c.startswith("SETUP::"):
        pre=c[7:]+"::"; m=0
        for k,n in num.items():
            if k.startswith(pre): m|=1<<n
        return m or None
    return None
_rc={}
def R(c):
    if c not in _rc: _rc[c]=resolve(c)
    return _rc[c]
lines={}   # file -> line -> int mask
imp={}     # file -> set(lines) executed in "" context
phases={}  # file -> line -> {import, warmup, collect:<testfile>, other}
unknown=set()
for i in range(4):
    d=coverage.CoverageData(basename=f"out{i}.cov"); d.read()
    for f in d.measured_files():
        rel=os.path.relpath(f,ROOT)
        for ctx in d.measured_contexts():
            pass
        ctxmap=d.contexts_by_lineno(f)
        for ln,ctxs in ctxmap.items():
            for c in ctxs:
                if c=="" or c in ("IMPORT","WARMUP") or c.startswith("COLLECT::"):
                    imp.setdefault(rel,set()).add(ln)
                    kind = "import" if c=="IMPORT" else "warmup" if c=="WARMUP" else ("collect:"+c[9:]) if c.startswith("COLLECT::") else "other"
                    phases.setdefault(rel,{}).setdefault(str(ln),set()).add(kind)
                    continue
                n=R(c)
                if n is None: unknown.add(c); continue
                lines.setdefault(rel,{}).setdefault(ln,0)
                lines[rel][ln]|=n
reads={}
for i in range(4):
    for k,v in json.load(open(f"out{i}.reads.json")).items():
        for p in v:
            if R(k):
                reads[p]=reads.get(p,0)|R(k)
            elif k=="" : pass
            else: unknown.add(k)
classes={}
for i in range(4):
    for k,v in json.load(open(f"out{i}.classes.json")).items():
        if not R(k): continue
        for c in v: classes[c]=classes.get(c,0)|R(k)
tacc={}; tphase={}; talias={}; tleaky=set(); tderived={}
for i in range(4):
    A=json.load(open(f"out{i}.acc.json"))
    talias.update(A["alias"]); tleaky|=set(A["leaky"]); tderived.update({k:v for k,v in A["derived"].items() if v})
    for c,lst in A["acc"].items():
        ph=None
        if "::" in c and not c.startswith(("SETUP::","COLLECT::")) and c not in num: continue  # skipped test
        if c=="WARMUSE": ph="warmuse"
        elif c=="WARMUP": ph="warmup"
        elif c.startswith("COLLECT::"): ph="collect:"+c[9:]
        elif c=="" or c=="IMPORT": ph="other"
        m=R(c) if ph in (None,) or (ph or "").startswith("collect:") else None
        if ph is None and m is None:
            ph="other"
        for n,k in lst:
            if m:
                tacc.setdefault(n,{})
                tacc[n][k]=tacc[n].get(k,0)|m
            if ph:
                tphase.setdefault(n,{}).setdefault(k,set()).add(ph)
print("unknown",len(unknown),list(unknown)[:5])
out={"lines":{f:{str(l):format(m,'x') for l,m in d.items()} for f,d in lines.items()},
     "import":{f:sorted(s) for f,s in imp.items()},
     "phases":{f:{l:sorted(k) for l,k in d.items()} for f,d in phases.items()},
     "reads":{p:format(m,'x') for p,m in reads.items()},
     "classes":{c:format(m,'x') for c,m in classes.items()},
     "tacc":{n:{k:format(m,'x') for k,m in d.items()} for n,d in tacc.items()},
     "tphase":{n:{k:sorted(v) for k,v in d.items()} for n,d in tphase.items()},
     "talias":talias,"tleaky":sorted(tleaky),"tderived":tderived}
json.dump(out,open("map.json","w"),separators=(',',':'))
print(len(lines), sum(len(d) for d in lines.values()), len(reads), os.path.getsize("map.json"))
